#include <stdio.h>

int main(void)
{
    printf("Yes we can");

    return 0;
}