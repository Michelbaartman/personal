/*
 ============================================================================
 Name        : func.h
 Author      : J. Kaldeway
 ============================================================================
 */

#ifndef _FUNC_H
#define _FUNC_H

void func1(void);
extern int glob1;
extern int glob2;

#endif /* _FUNC_H */
